declare var global: typeof globalThis;
