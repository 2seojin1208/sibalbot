import type { APIBaseInteraction } from './base';
import type { InteractionType } from './responses';
export declare type APIPingInteraction = APIBaseInteraction<InteractionType.Ping, never>;
//# sourceMappingURL=ping.d.ts.map