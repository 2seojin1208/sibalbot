import type { APIBaseInteraction, APIChatInputApplicationCommandInteractionData, InteractionType } from '../index';
export declare type APIApplicationCommandAutocompleteInteraction = APIBaseInteraction<InteractionType.ApplicationCommandAutocomplete, APIChatInputApplicationCommandInteractionData>;
//# sourceMappingURL=autocomplete.d.ts.map