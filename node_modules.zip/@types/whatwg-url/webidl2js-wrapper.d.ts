import * as URL from "./dist/URL";
import * as URLSearchParams from "./dist/URLSearchParams";

export { URL, URLSearchParams };
